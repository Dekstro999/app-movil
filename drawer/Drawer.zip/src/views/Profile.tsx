import { useState } from "react";
import { StyleSheet, Text, View ,KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard} from "react-native";
import { TextInput } from "react-native-gesture-handler";
// import PasswordInput from "../components/PasswordInput";

export default function Profile() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");


  return (
    <KeyboardAvoidingView behavior="padding" style={styles.container}>
      <View style={styles.container}>
        <Text>Profile Screen</Text>
      </View>

      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>

      {/* formulario */}
      <View style={styles.container}>
        {/* <TextInput
        keyboardType="default"
        keyboardType="email-address"
        keyboardType="numeric"
        keyboardType="phone-pad"
      /> */}

        {/* validaciones */}
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Enter your name"
          style={styles.Input}
        />

        <TextInput
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          placeholder="Enter your email"
          style={styles.Input}
        />

        <TextInput
          keyboardType="phone-pad"
          value={phone}
          onChangeText={setPhone}
          placeholder="Enter your phone number"
          style={styles.Input}
        />

        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="Enter your password"
          secureTextEntry
          style={styles.Input}
          />

      </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
    alignItems: "center",
    justifyContent: "center",

  },
  Input: {
    borderWidth: 1,
    borderColor: "#c5c5c5",
    padding: 20,
    width: "80%",
    marginTop: 10
  }
});
