import { DefaultTheme, NavigationContainer, NavigatorScreenParams } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import Home from "./src/views/Home";
import { AntDesign, MaterialIcons } from "@expo/vector-icons";
import Profile from "./src/views/Profile";
import Settings from "./src/views/Settings";
import Details from "./src/views/Details";
import Practica17 from "./src/views/Practica17";
import CustomDrawerContent from "./src/components/CustomDrawerContent";
import { Linking, TouchableOpacity } from "react-native";
import * as ExpoLinking from 'expo-linking';
import { LinkingOptions } from "@react-navigation/native";

// Deep Linking Configuration
const linking: LinkingOptions<RootDrawerParamList> = {
  prefixes: [ExpoLinking.createURL('/'), 'myapp://'],
  config: {
    screens: {
      Inicio: {
        screens: {
          HomeTabs: {
            screens: {
              Home: 'home',
              Profile: 'profile',
              Settings: 'settings',
              Details: 'details/:from?',
              Practica17: 'practica17',
            },
          },  
        },
       },
     },
   },
};


export type HomeTabsParamList = {
    Home: undefined;
    Profile: undefined;
    Settings: undefined;
    Details: { from?: string } | undefined;
    Practica17: undefined;
};

export type MainStackParamList = {
  HomeTabs: NavigatorScreenParams<HomeTabsParamList> | undefined;
};


export type RootDrawerParamList = {
  Inicio: NavigatorScreenParams<MainStackParamList> | undefined;
};


const Tab= createBottomTabNavigator<HomeTabsParamList>();
const Stack = createNativeStackNavigator<MainStackParamList>();
const Drawer = createDrawerNavigator<RootDrawerParamList>();


function HomeTabsNavigator() {
    return (
        <Tab.Navigator
            screenOptions={{
                headerShown: false,
                tabBarActiveTintColor: "#9000d8",
                tabBarInactiveTintColor: "#6b5176",
            }}
        >
            <Tab.Screen name="Home" component={Home} options={{ 
              title: "Inicio",
              tabBarIcon: ({ color, size }) => (
                <AntDesign name="home" size={size} color={color} />
              ),
              }} 
              />

              <Tab.Screen name="Profile" component={Profile} options={{ 
              title: "Perfil",
              tabBarIcon: ({ color, size }) => (
                <AntDesign name="user" size={size} color={color} />
              ),
              }} 
              />

              <Tab.Screen name="Settings" component={Settings} options={{ 
              title: "Configuración",
              tabBarIcon: ({ color, size }) => (
                <AntDesign name="setting" size={size} color={color} />
              ),
              }} 
              />

              <Tab.Screen name="Details" component={Details} options={{ 
              title: "Detalles",
              tabBarIcon: ({ color, size }) => (
                <AntDesign name="edit" size={size} color={color} />
              ),
              }} 
              />

              <Tab.Screen name="Practica17" component={Practica17} options={{ 
              title: "Práctica 17",
              tabBarIcon: ({ color, size }) => (
                <AntDesign name="form" size={size} color={color} />
              ),
              }} 
              />

        </Tab.Navigator>
    );
}


function MainStackNavigator() {
    return (
        <Stack.Navigator
          screenOptions={({ navigation }: any) => ({
            headerShown: true,
            headerStyle: {
              backgroundColor: "#480082",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "700",
            },
            headerLeft: () => (
              <TouchableOpacity
                onPress={() => navigation.toggleDrawer()}
                style={{ marginLeft: 16 }}
              >
                <MaterialIcons name="menu" size={28} color="#fff" />
              </TouchableOpacity>
            ),
          })}
        >
          <Stack.Screen 
            name="HomeTabs" 
            component={HomeTabsNavigator}
            options={{ title: " HOME TABS" }}
          />
        </Stack.Navigator>
    );
}


export default function App() {
    return (
      <NavigationContainer 
        linking={linking}
        fallback={<Home />}
        theme={{
        ...DefaultTheme,
        colors: {
          ...DefaultTheme.colors,
          background: "#f8f8f8",
        },
      }}>
        <Drawer.Navigator 
        initialRouteName="Inicio"
        drawerContent={(props: any) => <CustomDrawerContent {...props} />}
         screenOptions={{
          headerShown: false,
          drawerActiveTintColor: "#380f76",
        }}>
          <Drawer.Screen 
          name="Inicio" 
          component={MainStackNavigator}
          options={{title: "Navegación Principal"}}
          />
         </Drawer.Navigator>
      </NavigationContainer>
    );
}